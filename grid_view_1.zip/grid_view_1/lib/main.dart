import 'package:flutter/material.dart';

void main() => runApp(MaterialApp(
  //title: "Site Engineer Info:",
  home: HomePage(),
));
class HomePage extends StatefulWidget {
  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(

      appBar: AppBar(
        title: Text("Site Engineer Info"),
      ),
      body: Container(
        child: Engineer(),
      ),
    );
  }
}
class Engineer extends StatefulWidget {
  @override
  _EngineerState createState() => _EngineerState();
}

class _EngineerState extends State<Engineer> {
  final list_item = [
    {
      "Name" : "SE1",
      "Assigned_projects" : 5,
    },
    {
      "Name" : "SE2",
      "Assigned_projects" : 7,
    },
    {
      "Name" : "SE3",
      "Assigned_projects" : 3,
    },
    {
      "Name" : "SE4",
      "Assigned_projects" : 5,
    },
    {
      "Name" : "SE5",
      "Assigned_projects" : 6,
    },
    {
      "Name" : "SE6",
      "Assigned_projects" : 2,
    },
    {
      "Name" : "SE1",
      "Assigned_projects" : 5,
    },
    {
      "Name" : "SE7",
      "Assigned_projects" : 6,
    },
    {
      "Name" : "SE8",
      "Assigned_projects" : 7,
    },
    {
      "Name" : "SE9",
      "Assigned_projects" : 1,
    },
    {
      "Name" : "SE10",
      "Assigned_projects" : 5,
    },
    {
      "Name" : "SE11",
      "Assigned_projects" : 4,
    },
    {
      "Name" : "SE12",
      "Assigned_projects" : 6,
    },
  ];
  @override
  Widget build(BuildContext context) {
    return GridView.builder(
      itemCount: list_item.length,
        gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 3),
        itemBuilder: (BuildContext context, int index)
    {
      return Engineerinfo(
        name: list_item[index]['Name'],
        assigned_projects: list_item[index]['Assigned_projects'],
      );
    });
  }
}
class Engineerinfo extends StatelessWidget {
  final name;
  final assigned_projects;
  Engineerinfo(
      {
        this.name,
        this.assigned_projects
      });
  @override
  Widget build(BuildContext context) {
    return Card(
      child: Hero(tag: name,
      child: Material(
        child: InkWell(
          onTap: (){},
          child: GridTile(
            child: Container(
              color: Colors.black,
            ),
            footer: Container(
              color: Colors.white,
              child: ListTile(
                leading: Text(name,style: TextStyle(fontWeight: FontWeight.bold)),
                title: Text('$assigned_projects', style: TextStyle(fontWeight: FontWeight.bold)),
              ),
            ),
              //child: null,
          ),
        ),
      ),),
    );
  }
}


