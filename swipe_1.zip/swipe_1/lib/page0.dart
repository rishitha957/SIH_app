

import 'package:flutter/material.dart';

/*void main() {
  runApp(new TileApp());

}*/

class page0 extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return new MaterialApp(
      home: new Scaffold(
        appBar: new AppBar(
          title: new Center(
            child: Text('Asset types'),
          ),
        ),
        body: new ListView.builder(
          itemBuilder: (BuildContext context, int index) {
            return new StuffInTiles(listOfTiles[index]);
          },
          itemCount: listOfTiles.length,
        ),
      ),
    );
  }
}

class StuffInTiles extends StatelessWidget {
  final MyTile myTile;
  StuffInTiles(this.myTile);

  @override
  Widget build(BuildContext context) {
    return _buildTiles(myTile);
  }

  Widget _buildTiles(MyTile t) {
    if (t.children.isEmpty)
      return new ListTile(
          dense: true,
          enabled: true,
          isThreeLine: false,
          onLongPress: () => print("long press"),
          onTap: () => print("tap"),
          //subtitle: new Text("Subtitle"),
          //leading: new Text("Leading"),
          selected: true,
          //trailing: new Text("trailing"),
          title: new Text(t.title));

    return new ExpansionTile(
      key: new PageStorageKey<int>(3),
      title: new Text(t.title),
      children: t.children.map(_buildTiles).toList(),
    );
  }
}

class MyTile {
  String title;
  TextEditingController controller1 = new TextEditingController();
  List<MyTile> children;
  MyTile(this.title, [this.children = const <MyTile>[]]);
}

List<MyTile> listOfTiles = <MyTile>[
  new MyTile(
    'Vehicle',
    <MyTile>[
      new MyTile(
        'Car',
        <MyTile>[
          new MyTile(
            'Engine'
          ),
          new MyTile('Registration Number'),
          new MyTile('field1'),
        ],
      ),
      new MyTile('Truck'),
      new MyTile('Bus'),
    ],
  ),
  new MyTile(
    'Land',
    <MyTile>[
      new MyTile(
      'Area'
      ),
     new MyTile('Field1'),
    ],
  ),
  new MyTile(
    'Small scale products',
    <MyTile>[
      new MyTile('Mobiles'),
      new MyTile('Computers'),
      new MyTile(
        'Head phones',
      ),
    ],
  ),
];