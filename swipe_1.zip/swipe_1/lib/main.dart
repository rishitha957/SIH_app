import 'package:flutter/material.dart';
import 'package:swipe_1/page2.dart';
import 'package:swipe_1/page3.dart';
import 'package:swipe_1/page0.dart';
import 'package:swipe_1/page4.dart';
void main() => runApp(MyApp());

class MyApp extends StatelessWidget {
//  class QuoteApp extends StatelessWidget {
  List<Widget> pages = [page0(), page2(), page3(), page4()];
  @override
  Widget build(BuildContext context) {
  return new MaterialApp(
  title: 'Motivational Quote App',
  home: PageView.builder(
  itemCount: pages.length,
  itemBuilder: (BuildContext context, int index) => pages[index],
  ),
  );
  }
  //}
}

