import 'package:flutter/material.dart';
void main() => runApp(MaterialApp(
  //title: "Site Engineer Info:",
  home: HomePage(),
));
class HomePage extends StatefulWidget {
  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  //int counter = 0;
  String dropdownValue = "choose Filter to sort";
  @override
  Widget build(BuildContext context) {
    return Scaffold(

      appBar: AppBar(
        title: new Center(
          child: new Text("Status",textAlign: TextAlign.center),
        )
      ),
      body: Container(
        child: Engineer(),
      ),
      floatingActionButton: Container(
       // color: Colors.lightBlue,
        child: DropdownButton<String>(
            //color: Colors.lightBlue,
            //String : dropdownValue,
            value: dropdownValue,
            onChanged: (String newValue){
              setState((){
                if(newValue != null)
                  dropdownValue = newValue;
              });
            },
          items: <String>['By Site Engineer','By open projects' ]
            .map<DropdownMenuItem<String>>((String value){
              return DropdownMenuItem<String>(
                value: value,
                child: Text(value),
              );
          }
        )
            .toList()
        )
      ),
    );
  }
}
class Engineer extends StatefulWidget {
  @override
  _EngineerState createState() => _EngineerState();

}

class _EngineerState extends State<Engineer> {

  final list_item = [
    {
      "Name" : "SE1",
      "pic" : "images/contact.jpg",
      "Assigned_projects" : 5,
    },
    {
      "Name" : "SE2",
      "pic" : "images/contact.jpg",
      "Assigned_projects" : 7,
    },
    {
      "Name" : "SE3",
      "pic" : "images/contact.jpg",
      "Assigned_projects" : 3,
    },
    {
      "Name" : "SE4",
      "pic" : "images/contact.jpg",
      "Assigned_projects" : 5,
    },
    {
      "Name" : "SE5",
      "pic" : "images/contact.jpg",
      "Assigned_projects" : 6,
    },
    {
      "Name" : "SE6",
      "pic" : "images/contact.jpg",
      "Assigned_projects" : 2,
    },
    {
      "Name" : "SE1",
      "pic" : "images/contact.jpg",
      "Assigned_projects" : 5,
    },
    {
      "Name" : "SE7",
      "pic" : "images/contact.jpg",
      "Assigned_projects" : 6,
    },
    {
      "Name" : "SE8",
      "pic" : "images/contact.jpg",
      "Assigned_projects" : 7,
    },
    {
      "Name" : "SE9",
      "pic" : "images/contact.jpg",
      "Assigned_projects" : 1,
    },
    {
      "Name" : "SE10",
      "pic" : "images/contact.jpg",
      "Assigned_projects" : 5,
    },
    {
      "Name" : "SE11",
      "pic" : "images/contact.jpg",
      "Assigned_projects" : 4,
    },
    {
      "Name" : "SE12",
      "pic" : "images/contact.jpg",
      "Assigned_projects" : 6,
    },
  ];
  @override
  Widget build(BuildContext context) {
    return GridView.builder(
      itemCount: list_item.length,
        gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 4),
        itemBuilder: (BuildContext context, int index)
    {
      return Engineerinfo(
        name: list_item[index]['Name'],
        assigned_projects: list_item[index]['Assigned_projects'],
        pic : list_item[index]['pic'],
      );
    });
  }
}
class Engineerinfo extends StatelessWidget {
  final name;
  final assigned_projects;
  final pic;
  bool tappedYes = false;
  Engineerinfo(
      {
        this.name,
        this.assigned_projects,
        this.pic,
      });
  setState(){
    tappedYes = true;
    //if(tappedYes == true)
  }
  @override
  Widget build(BuildContext context) {
    return Card(
      child: Hero(tag: name,
      child: Material(
        child: InkWell(
          onTap: null,
          child: GridTile(
            child: Material(
              child: Image.asset(pic),
            ),
            footer: Container(
              //color: Colors.white,
              child: ListTile(
                leading: Text(name,style: TextStyle(fontWeight: FontWeight.bold)),
                title: Text('$assigned_projects', style: TextStyle(fontWeight: FontWeight.bold)),
              ),
            ),
              //child: null,
          ),
        ),
      ),),
    );
  }
}



