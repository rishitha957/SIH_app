import 'package:flutter/material.dart';
import 'package:datetime_picker_formfield/datetime_picker_formfield.dart';
import 'package:intl/intl.dart';

void main(){
  runApp(new MaterialApp(
    home: new page2(),
  ));
}

class page2 extends StatefulWidget {
  @override
  _HomeState createState() => new _HomeState();
}

class _HomeState extends State<page2> {

  List<String> vehicle=["Car","Truck", "Bus","Traveller","MiniVan"];
  String _vehicle="car";

  String _set="";

  TextEditingController controller1= new TextEditingController();
  TextEditingController controller2= new TextEditingController();
  TextEditingController controller3= new TextEditingController();
  TextEditingController controller4= new TextEditingController();
  TextEditingController controller5 = new TextEditingController();
  TextEditingController controller6 = new TextEditingController();
  TextEditingController controller7 = new TextEditingController();
  TextEditingController controller8 = new TextEditingController();
  TextEditingController controller9 = new TextEditingController();
void _fillValue(String value){
    setState((){
      _set=value;
    });
  }

  void  fillVehicle(String value){
    setState((){
      _vehicle=value;
    });
  }
  void updateInputType({bool date, bool time}) {
    date = date ?? inputType != InputType.time;
    time = time ?? inputType != InputType.date;
    setState(() => inputType =
    date ? time ? InputType.both : InputType.date : InputType.time);
  }
  void data(){
    AlertDialog alertDialog = new AlertDialog(
      content: new Container(
        height: 200.0,
        child: new Column(
          children: <Widget>[
            new Text("Client Name : ${controller1.text}"),
            new Text("Contact Number : ${controller2.text}"),
            new Text("Contract Number : ${controller3.text}"),
            new Text("Employee Id : ${controller5.text}"),
            new Text("Location : ${controller6.text}"),
            new Text("Make : ${controller7.text}"),
            new Text("Model : ${controller8.text}"),
            new Text("Purpose : ${controller9.text}"),
            new Text("Vehicle : $_vehicle"),
            new RaisedButton(
              child: new Text("OK"),
              onPressed: ()=>Navigator.pop(context),
            )
          ],
        ),
      ),
    );
    showDialog(context: context,child:alertDialog );
  }
  final formats = {
    InputType.both: DateFormat("EEEE, MMMM d, yyyy 'at' h: mma"),
    InputType.date: DateFormat('yyyy-MM-dd'),
    InputType.time: DateFormat("HH:mm"),
  };
  InputType inputType = InputType.both;
  bool editable = true;
  DateTime date;
  @override
  Widget build(BuildContext context) {
    return new Scaffold(
      appBar: new AppBar(
        leading: new Icon(Icons.arrow_back),
        title: new Text("Create New Project", textAlign: TextAlign.center,),
        backgroundColor: Colors.blue,
      ),


      body: new ListView(
        children: <Widget>[
          new Container(
            padding: new EdgeInsets.all(10.0),
            child:  new Column(
              children: <Widget>[
                new TextField(
                  controller: controller1,
                  decoration: new InputDecoration(
                      hintText: "Client Name",
                      labelText: "Client Name",
                      border: new OutlineInputBorder(
                          borderRadius: new BorderRadius.circular(0.0)
                      )

                  ),
                ),

                new Padding(padding: new EdgeInsets.only(top: 15.0),),
                new TextField(
                  controller: controller2,
                  //obscureText: true,
                  decoration: new InputDecoration(
                      hintText: "Contact Number",
                      labelText: "Contact Number",
                      border: new OutlineInputBorder(
                          borderRadius: new BorderRadius.circular(0.0)
                      )

                  ),
                ),
                new Padding(padding: new EdgeInsets.only(top: 15.0),),
                new TextField(
                  controller:  controller3,
                  //maxLines: 3,
                  decoration: new InputDecoration(
                      hintText: "Contract Number",
                      labelText: "Contract Number",
                      border: new OutlineInputBorder(
                          borderRadius: new BorderRadius.circular(0.0)
                      )

                  ),
                ),

                 new Padding(padding: new EdgeInsets.only(top:15.0),),
                /*new TextField(
                  controller: controller4,
                  //obscureText: true,
                  decoration: new InputDecoration(
                      hintText: "Deadline",
                      labelText: "Deadline",
                      border: new OutlineInputBorder(
                          borderRadius: new BorderRadius.circular(0.0)
                      )

                  ),
                ),*/
                new DateTimePickerFormField(
                    inputType: inputType,
                    format: formats[inputType],
                    editable: editable,
                    decoration: InputDecoration(
                      labelText: 'Date/Time', hasFloatingPlaceholder: false,
                        border: new OutlineInputBorder(
                           borderRadius: new BorderRadius.circular(0.0)
                )
                    ),onChanged: (dt)=>setState(()=>date = dt),
                ),
                //Text('Date value: $date'),
                SizedBox(height: 16.0),
                new Padding(padding: new EdgeInsets.only(top: 15.0),),
                new TextField(
                  controller: controller5,
                  decoration: new InputDecoration(
                    hintText: "Employee Id",
                    labelText: "Employee Id",
                    border: new OutlineInputBorder(
                      borderRadius: new BorderRadius.circular(0.0)
                    )
                  ),
                ),
               new Padding(padding: new EdgeInsets.only(top: 15.0),),
                new TextField(
                  controller: controller6,
                  maxLines: 3,
                  decoration: new InputDecoration(
                      hintText: "Location",
                      labelText: "Location",
                      border: new OutlineInputBorder(
                          borderRadius: new BorderRadius.circular(0.0)
                      )
                  ),
                ),
                new Padding(padding: new EdgeInsets.only(top: 15.0),),
                new TextField(
                  controller: controller7,
                  decoration: new InputDecoration(
                      hintText: "Make",
                      labelText: "Company name",
                      border: new OutlineInputBorder(
                          borderRadius: new BorderRadius.circular(0.0)
                      )
                  ),
                ),
                new Padding(padding: new EdgeInsets.only(top: 15.0),),
                new TextField(
                  controller: controller8,
                  decoration: new InputDecoration(
                      hintText: "Model",
                      labelText: "Model",
                      border: new OutlineInputBorder(
                          borderRadius: new BorderRadius.circular(0.0)
                      )
                  ),
                ),
                new Padding(padding: new EdgeInsets.only(top: 15.0),),
                new TextField(
                  controller: controller9,
                  decoration: new InputDecoration(
                      hintText: "Purpose",
                      labelText: "Purpose",
                      border: new OutlineInputBorder(
                          borderRadius: new BorderRadius.circular(0.0)
                      )
                  ),
                ),

                /*new Row(
                  children: <Widget>[
                    new Text("Vehicle    ",style: new TextStyle(fontSize: 18.0,color: Colors.blue),),
                    new DropdownButton(
                      onChanged: (String value){
                        fillVehicle(value);
                      },
                      value: _vehicle,
                      items: vehicle.map((String value){
                        return new DropdownMenuItem(
                          value: value,
                          child: new Text(value),
                        );
                      }).toList(),
                    )
                  ],
                ),*/

                new RaisedButton(
                  child: new Text("OK"),
                  color: Colors.lightBlueAccent,
                  onPressed: (){ data();},
                )

              ],
            ),
          ),
        ],
      ),
    );
  }
}

