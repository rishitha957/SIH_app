//
//  Generated file. Do not edit.
//

#import "GeneratedPluginRegistrant.h"
#import <local_auth/LocalAuthPlugin.h>

@implementation GeneratedPluginRegistrant

+ (void)registerWithRegistry:(NSObject<FlutterPluginRegistry>*)registry {
  [FLTLocalAuthPlugin registerWithRegistrar:[registry registrarForPlugin:@"FLTLocalAuthPlugin"]];
}

@end
