import 'package:flutter/material.dart';
import 'package:grid_view_1/dialogue.dart';
import 'package:grid_view_1/local_auth.dart';
import 'package:flutter/services.dart';
import 'package:local_auth/local_auth.dart';
void main() => runApp(MaterialApp(
  //title: "Site Engineer Info:",
  home: HomePage(),
));
class Auth{
  String authorized = "Not Authorized";

  static void authenticate() async{
    var auth = LocalAuthentication();
    bool authenticated = false;
    authenticated = await auth.authenticateWithBiometrics(
      localizedReason: 'Confirm assigning task to Site Engineer by scanning fingerprint',
      useErrorDialogs: true,
      stickyAuth: false
    );
  }
}
class HomePage extends StatefulWidget {
  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(

      appBar: AppBar(
        title: Text("Site Engineer Info",textAlign: TextAlign.center),
      ),
      body: Container(
        child: Engineer(),
      ),
    );
  }
}
class Engineer extends StatefulWidget {
  @override
  _EngineerState createState() => _EngineerState();

}

class _EngineerState extends State<Engineer> {

  final list_item = [
    {
      "Name" : "SE1",
      "pic" : "images/contact.jpg",
      "Assigned_projects" : 5,
    },
    {
      "Name" : "SE2",
      "pic" : "images/contact.jpg",
      "Assigned_projects" : 7,
    },
    {
      "Name" : "SE3",
      "pic" : "images/contact.jpg",
      "Assigned_projects" : 3,
    },
    {
      "Name" : "SE4",
      "pic" : "images/contact.jpg",
      "Assigned_projects" : 5,
    },
    {
      "Name" : "SE5",
      "pic" : "images/contact.jpg",
      "Assigned_projects" : 6,
    },
    {
      "Name" : "SE6",
      "pic" : "images/contact.jpg",
      "Assigned_projects" : 2,
    },
    {
      "Name" : "SE1",
      "pic" : "images/contact.jpg",
      "Assigned_projects" : 5,
    },
    {
      "Name" : "SE7",
      "pic" : "images/contact.jpg",
      "Assigned_projects" : 6,
    },
    {
      "Name" : "SE8",
      "pic" : "images/contact.jpg",
      "Assigned_projects" : 7,
    },
    {
      "Name" : "SE9",
      "pic" : "images/contact.jpg",
      "Assigned_projects" : 1,
    },
    {
      "Name" : "SE10",
      "pic" : "images/contact.jpg",
      "Assigned_projects" : 5,
    },
    {
      "Name" : "SE11",
      "pic" : "images/contact.jpg",
      "Assigned_projects" : 4,
    },
    {
      "Name" : "SE12",
      "pic" : "images/contact.jpg",
      "Assigned_projects" : 6,
    },
  ];
  @override
  Widget build(BuildContext context) {
    return GridView.builder(
      itemCount: list_item.length,
        gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 3),
        itemBuilder: (BuildContext context, int index)
    {
      return Engineerinfo(
        name: list_item[index]['Name'],
        assigned_projects: list_item[index]['Assigned_projects'],
        pic : list_item[index]['pic'],
      );
    });
  }
}
class Engineerinfo extends StatelessWidget {
  final name;
  final assigned_projects;
  final pic;
  bool tappedYes = false;
  Engineerinfo(
      {
        this.name,
        this.assigned_projects,
        this.pic,
      });
  setState(){
    tappedYes = true;
    //if(tappedYes == true)
  }
  @override
  Widget build(BuildContext context) {
    return Card(
      child: Hero(tag: name,
      child: Material(
        child: InkWell(
          onTap: ()async {
              final action = await Dialogues.yesAbortDialog(context, 'Authentication', 'Allow us to access your Fingerprint');
              if (action == DialogueAction.yes) {

                setState() => tappedYes = true;

              } else {
                setState() => tappedYes = false;
              }
              Auth.authenticate();
          },
          child: GridTile(
            child: Material(
              child: Image.asset(pic),
            ),
            footer: Container(
              //color: Colors.white,
              child: ListTile(
                leading: Text(name,style: TextStyle(fontWeight: FontWeight.bold)),
                title: Text('$assigned_projects', style: TextStyle(fontWeight: FontWeight.bold)),
              ),
            ),
              //child: null,
          ),
        ),
      ),),
    );
  }
}



